<?php

namespace Database\Seeders;

use App\Role;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('users')->insert([
            [
                'first_name' => 'admin',
                'last_name' => 'admin',
                'email' => 'admin@email.com',
                'role_id' => Role::ADMIN,
                'password' => bcrypt('admin'),
            ],
            [
                'first_name' => 'teacher ',
                'last_name' => 'teacher',
                'email' => 'teacher@email.com',
                'role_id' => Role::TEACHER,
                'password' => bcrypt('teacher'),
            ],
            [
                'first_name' => 'student',
                'last_name' => 'student',
                'email' => 'student@email.com',
                'role_id' => Role::STUDENT,
                'password' => bcrypt('student'),
            ],
        ]);

        for ($i = 0; $i < 10; $i ++) {
            DB::table('users')->insert([
                [
                    'first_name' => 'teacher',
                    'last_name' => Str::random(4),
                    'email' => 'teacher-'. $i . '@email.com',
                    'role_id' => Role::TEACHER,
                    'password' => bcrypt('teacher'),
                ],
                [
                    'first_name' => 'student',
                    'last_name' => Str::random(4),
                    'email' => 'student'. $i . '@email.com',
                    'role_id' => Role::STUDENT,
                    'password' => bcrypt('student'),
                ],
            ]);
        }
    }
}
