<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ModuleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('modules')->insert([
            ['name' => 'Programmation Orientée Objets en Java et Programmation Mobile'],
            ['name' => 'Développement web et Frameworks  (php, zend, samfony)'],
            ['name' => 'Théorie des graphes & Applications'],
            ['name' => 'Conception Orienté Objet'],
            ['name' => 'Statistique descriptive et inférentielle'],
            ['name' => 'Management & comptabilité'],
            ['name' => 'Systèmes embarqués  & Internet des objets'],
            ['name' => 'Gestion de projet & Méthode Agiles'],
            ['name' => 'Administration des bases  de données'],
            ['name' => "Méthodologies de l'Intelligence Artificielle"],
            ['name' => "Architectures web distribuées  (j2ee)"],
            ['name' => "Anglais  Avancée & Techniques d'exposition"],
            ['name' => "Systèmes d’informations décisionnels & data mininig"],
            ['name' => "Technologies .net"],
            ['name' => "Machine learning &  Systèmes multi-agents"],
            ['name' => "Administration systèmes et réseaux"],
            ['name' => "Processus audit & Urbanisation et architectures des systèmes d’informations"],
            ['name' => "Droit des entreprises"],
            ['name' => "Business  Intelligence &  Big Data"],
            ['name' => "Vision Artificielle"],
            ['name' => "Sécurité Intelligente des Systèmes d’informations"],
            ['name' => "Cloud Intelligence & virtualisation"],
            ['name' => "Intelligence économique & Soft Skills"],
            ['name' => "Anglais professionnel & techniques de coaching"],
            ['name' => "Projet de fin d'études"],
        ]);
    }
}
