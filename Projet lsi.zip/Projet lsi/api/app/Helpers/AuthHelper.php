<?php

namespace App\Helpers;

use App\Role;
use App\User;
use Illuminate\Support\Facades\Auth;

class AuthHelper
{
    public function isAuthenticated()
    {
        return Auth::guard()->user() instanceof User;
    }

    public function isAdmin()
    {
        return $this->isAuthenticated() && Auth::guard()->user()->role_id === Role::ADMIN;
    }

    public function isStudent()
    {
        return $this->isAuthenticated() && Auth::guard()->user()->role_id === Role::STUDENT;
    }
    
    public function isTeacher()
    {
        return $this->isAuthenticated() && Auth::guard()->user()->role_id === Role::TEACHER;
    }
}
