<?php

namespace App\Http\Controllers;

use App\Helpers\AuthHelper;
use App\Http\Requests\UserRequest;
use App\Project;
use App\User;
use App\Year;
use Illuminate\Http\Request;

class UserController extends Controller
{
    public function index(Request $request)
    {
        $currentYear = Year::where('year', (date('Y') - 1) . '/' . date('Y'))->first()->id;

        $users = User::where('role_id', $request->get('role'))
            ->with(['modules' => function ($query) use ($request, $currentYear) {
                $query
                    ->select('modules.id', 'modules.name')
                    ->where('year_id', $request->get('year', $currentYear))
                    ;
            }])
            ->get();

        return response($users, 200);
    }

    public function store(UserRequest $request)
    {
        $this->isAuthorized();

        $user = User::create($request->all());

        return response($user, 201);
    }

    public function show($id, Request $request)
    {
        $currentYear = Year::where('year', (date('Y') - 1) . '/' . date('Y'))->first()->id;

        $user = User::with(['modules' => function ($query) use ($request, $currentYear) {
            $query
                    ->select('modules.id', 'modules.name')
                    ->where('year_id', $request->get('year', $currentYear))
                    ;
        }])
        ->findOrFail($id);
        
        $user->project = Project::find($user->project_id);

        return response($user, 200);
    }

    public function update(UserRequest $request, $id)
    {
        $this->isAuthorized();

        $user = User::findOrFail($id);
        $user->update($request->all());

        return response($user, 200);
    }

    public function destroy($id)
    {
        $this->isAuthorized();
        
        User::destroy($id);

        return response(['success' => true], 204);
    }

    private function isAuthorized($for = false)
    {
        $authHelper = new AuthHelper;
        
        if ($for === 'student') {
            $role = $authHelper->isStudent() || $authHelper->isAdmin();
        } else if ($for === 'teacher') {
            $role = $authHelper->isTeacher() || $authHelper->isAdmin();
        } elseif ($for === 'all') {
            $role = true;
        } else {
            // Admin par default
            $role = $authHelper->isAdmin();
        }


        if (!($authHelper->isAuthenticated() && $role)) {
            throw new \Exception('Not allowed');
        }
    }
}
