<?php

namespace App\Http\Controllers;

use App\Helpers\AuthHelper;
use App\Project;
use App\User;
use Illuminate\Http\Request;

class ProjectController extends Controller
{
    public function index()
    {
        $projects = Project::with(['users' => function ($query) {
            $query->select('id', 'first_name', 'last_name', "email", "project_id");
        }])->get();

        return response($projects, 200);
    }

    public function show($id)
    {
        $project = Project::findOrFail($id);

        $project->users = User::where('project_id', $project->id)->get();

        return response($project, 200);
    }

    public function store(Request $request)
    {
        $this->isAuthorized();
        
        $data = $request->get('project');

        $project = new Project;
        $project->name = $data['name'];
        if (isset($data['note'])) {
            $project->note = $data['note'];
        }

        $project->save();
        
        User::whereIn('id', $request->get('users'))->update(['project_id' => $project->id]);
        
        return response($project, 201);
    }
    
    public function update(Request $request, $id)
    {
        $this->isAuthorized();
        
        $data = $request->get('project');

        $project = Project::findOrFail($id);
        if (isset($data['name'])) {
            $project->name = $data['name'];
            $project->note = $data['note'] ?? null;
            $project->save();
        }

        
        User::where('project_id', $project->id)->update(['project_id' => null]);

        User::whereIn('id', $request->get('users'))->update(['project_id' => $project->id]);

        return response($project, 200);
    }

    public function destroy($id)
    {
        $this->isAuthorized();
        
        Project::destroy($id);

        return response(['success' => true], 204);
    }

    private function isAuthorized($for = false)
    {
        $authHelper = new AuthHelper;
        
        if ($for === 'student') {
            $role = $authHelper->isStudent() || $authHelper->isAdmin();
        } else if ($for === 'teacher') {
            $role = $authHelper->isTeacher() || $authHelper->isAdmin();
        } elseif ($for === 'all') {
            $role = true;
        } else {
            // Admin par default
            $role = $authHelper->isAdmin();
        }

        if (!($authHelper->isAuthenticated() && $role)) {
            throw new \Exception('Not allowed');
        }
    }
}
