<?php

namespace App\Http\Controllers;

use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    public function login(Request $request)
    {
        $credentials = $request->only('email', 'password');

        if (!Auth::guard('web')->attempt($credentials)) {
            throw new Exception(401, __('Les informations saisies ne sont pas correctes'));
        }
        
        $user = Auth::guard()->user();

        if (count($user->tokens) > 0) {
            foreach ($user->tokens()->get() as $token) {
                $token->delete();
            }
        }

        // Get a new token
        $token = $user->createToken($user->email);


        return response()->json([
            'success' => true,
            'access-token' => $token->plainTextToken,
            'user' => $user
        ]);
    }

    public function logout()
    {
        $user = Auth::guard()->user();
        
        foreach ($user->tokens()->get() as $token) {
            $token->delete();
        }
        
        return response()->json(['logout' => true]);
    }
}
