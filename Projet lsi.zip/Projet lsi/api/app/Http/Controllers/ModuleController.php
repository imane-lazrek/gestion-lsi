<?php

namespace App\Http\Controllers;

use App\Helpers\AuthHelper;
use App\Module;
use App\Role;
use App\User;
use App\UserModule;
use App\Year;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ModuleController extends Controller
{
    public function index()
    {
        $modules = Module::all();

        return response($modules, 200);
    }

    public function show($id)
    {
        $module = Module::findOrFail($id);

        return response($module, 200);
    }

    // Affectation
    public function affectToUser(Request $request, User $user)
    {
        $currentYear = $this->getCurrentYear();

        if ($user->role_id === Role::ADMIN) {
            throw new \Exception("Admin ne peut pas etre affecté à un module");
        }

        $modules = array_flip($request->get('modules', []));
        $year = $request->get('year', $currentYear);

        $oldAffectations = DB::table('user_modules')
        ->where('year_id', '<>', $year)
        ->where('user_id', $user->id)
        ->select(['module_id', 'year_id'])
        ->get();
        

        foreach ($modules as $key => $value) {
            $modules[$key] = ['year_id' => $year];
        }
        
        // garder les affectations des ancienne annees
        foreach ($oldAffectations as $key => $affectation) {
            $modules[$affectation->module_id] = ['year_id' => $affectation->year_id];
        }

        $user->modules()->sync($modules);

        return response()->json(['success' => true]);
    }

    // Affectation d'une note
    public function affectNoteToModule(User $user, Module $module, Request $request)
    {
        $this->validate($request, ['note' => 'required']);

        $affectation = UserModule::where('year_id', $this->getCurrentYear())
            ->where('user_id', $user->id)
            ->where('module_id', $module->id)
            ->first()
        ;

        $affectation->note  = $request->get('note');
        $affectation->description  = $request->get('description');

        $affectation->save();

        return response()->json(['success' => true]);
    }

    private function isAuthorized($for = false)
    {
        $authHelper = new AuthHelper;
        
        if ($for === 'student') {
            $role = $authHelper->isStudent() || $authHelper->isAdmin();
        } else if ($for === 'teacher') {
            $role = $authHelper->isTeacher() || $authHelper->isAdmin();
        } elseif ($for === 'all') {
            $role = true;
        } else {
            // Admin par default
            $role = $authHelper->isAdmin();
        }

        if (!($authHelper->isAuthenticated() && $role)) {
            throw new \Exception('Not allowed');
        }
    }
    
    private function getCurrentYear()
    {
        return Year::where('year', (date('Y') - 1) . '/' . date('Y'))->first()->id;
    }
}
