<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Request;

class UserRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        if ($this->method() !== "PATCH") {
            return [
                'first_name' => ['required', 'alpha'],
                'last_name' => ['required', 'alpha'],
                'email' => ['required', 'email', 'unique:users'],
                'role_id' => ['required', 'integer'],
                'password' => ['required'],
            ];
        }

        return [
            'first_name' => ['alpha'],
            'last_name' => ['alpha'],
            'email' => [
                'required',
                'email',
                \Illuminate\Validation\Rule::unique('users')->ignore($this->segment(3))
            ]
        ];
    }
}
