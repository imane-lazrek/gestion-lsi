#Installation 

##Api: 
composer install
verifier les donnees de la db sur .env
	
Installer les migrations + les seeds

php artisan migrate:fresh --seed


lancer le serveur de development
	php artisan serve : le serveur devera se lancer sur http://127.0.0.1:8000
	
	
##Web
npm install

Lancement sur serveur web : npm run serve

Va donner generalemnt accès au http://localhost:8080/
