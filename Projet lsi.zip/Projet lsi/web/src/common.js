import axios from 'axios';
import jquery from 'jquery';
import toastr from 'toastr';

global.$ = jquery;

global.httpHeaders = {};
  
// Methodes communes
global.getToken = () => {
    if (!localStorage.token) {
        return null;
    }

    return localStorage.token;
}

global.logout = () => {
    localStorage.clear();

    window.location = '/login';
}

global.refreshTokens = () => {
    global.httpHeaders = {
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + localStorage.token
        }
    };
}

global.service = {};

global.service.users = {
    list: async (role) => {
        global.refreshTokens();
        
        return await axios
            .get(API_URL + '/api/users?role=' + role,  global.httpHeaders)
            .then((response) => {
                return response.data;
            }).catch(function (error) {
                if (error.response.status === 401) {
                    logout();
                }
            });    
    },
    get: async (userId) => {
        global.refreshTokens();
        
        return await axios
            .get(API_URL + '/api/users/' + userId,  global.httpHeaders)
            .then((response) => {
                return response.data;
            }).catch(function (error) {
                toastr.error("erreur lors de la récupération de l'utilisateur");
            });    
    },
    delete: async (userId) => {
        global.refreshTokens();
        
        return await axios
            .delete(API_URL + '/api/users/' + userId,  global.httpHeaders)
            .then((response) => {
                toastr.success("utilisateur supprime avec success");
                return response.data;
            }).catch(function (error) {
                toastr.error("Erreur lors de la suppression de l'utilisateur");
                if (error.response.status === 401) {
                    logout();
                }
            });    
    },
    create: async (data) => {
        global.refreshTokens();
        
        return await axios
            .post(API_URL + '/api/users', data, global.httpHeaders)
            .then((response) => {
                return response.data;
            }).catch(function (error) {
                toastr.error("Erreur lors de la création de l'utilisateur");   
            });    
    },
    edit: async (userId, data) => {
        global.refreshTokens();
        
        return await axios
            .patch(API_URL + '/api/users/'+ userId, data, global.httpHeaders)
            .then((response) => {
                toastr.success("utilisateur modifié avec success");
                return response.data;
            }).catch(function (error) {
                toastr.error("Erreur lors de la modification de l'utilisateur");   
            });    
    }
};

global.service.projects = {
    list: async () => {
        global.refreshTokens();
        
        return await axios
            .get(API_URL + '/api/projects',  global.httpHeaders)
            .then((response) => {
                return response.data;
            }).catch(function (error) {
                console.log(error);
            });    
    },
    get: async (projectId) => {
        global.refreshTokens();
        
        return await axios
            .get(API_URL + '/api/projects/' + projectId,  global.httpHeaders)
            .then((response) => {
                return response.data;
            }).catch(function (error) {
                toastr.error("erreur lors de la récupération du projet");
            });    
    },
    affect: async (projectId, data) => {
        global.refreshTokens();
        
        return await axios
            .post(API_URL + '/api/projects/affect/'+ projectId, {
                modules: data
            }, global.httpHeaders)
            .then((response) => {
                toastr.success("Projet affecté avec success");
                return response.data;
            }).catch(function (error) {
                console.log({error});
                toastr.error("Erreur lors de l'affectation du projet");   
            });    
    },
    delete: async (projectId) => {
        global.refreshTokens();
        
        return await axios
            .delete(API_URL + '/api/projects/' + projectId,  global.httpHeaders)
            .then((response) => {
                toastr.success("Projet supprimé avec success");
                return response.data;
            }).catch(function (error) {
                toastr.error("Erreur lors de la suppression du projet");
                if (error.response.status === 401) {
                    logout();
                }
            });
    },
    create: async (project, users) => {
        global.refreshTokens();
        
        return await axios
            .post(API_URL + '/api/projects',{
                project,
                users,
            }, global.httpHeaders)
            .then((response) => {
                return response.data;
            }).catch(function (error) {
                toastr.error("Erreur lors de la création du projet");   
            });    
    },
    edit: async (id, project, users) => {
        global.refreshTokens();
        
        return await axios
            .patch(API_URL + '/api/projects/'+ id, {
                project,
                users,
            }, global.httpHeaders)
            .then((response) => {
                toastr.success("utilisateur modifié avec success");
                return response.data;
            }).catch(function (error) {
                toastr.error("Erreur lors de la modification du projet");   
            });    
    }
};

global.service.modules = {
    get: async (id) => {
        global.refreshTokens();
        
        return await axios
            .get(API_URL + '/api/modules/' + id,  global.httpHeaders)
            .then((response) => {
                return response.data;
            }).catch(function (error) {
                console.log(error);
            });    
    },
    list: async () => {
        global.refreshTokens();
        
        return await axios
            .get(API_URL + '/api/modules',  global.httpHeaders)
            .then((response) => {
                return response.data;
            }).catch(function (error) {
                console.log(error);
            });    
    },
    affect: async (userId, data) => {
        global.refreshTokens();
        
        return await axios
            .post(API_URL + '/api/modules/affect/'+ userId, {
                modules: data
            }, global.httpHeaders)
            .then((response) => {
                toastr.success("Affectation modifié avec success");
                return response.data;
            }).catch(function (error) {
                console.log({error});
                toastr.error("Erreur lors de l'affectation des modules");   
            });    
    },
    note: async (userId, module) => {
        global.refreshTokens();
        
        return await axios
            .post(API_URL + '/api/notes/affect/'+ userId + '/' + module.id, {
                note: module.note
            }, global.httpHeaders)
            .then((response) => {
                toastr.success("Affectation de la note modifié avec success");
                return response.data;
            }).catch(function (error) {
                console.log({error});
                toastr.error("Erreur lors de l'affectation de la note");   
            });
    }
};
