import Vue from "vue";
import VueRouter from "vue-router";
import Login from "../views/Login.vue";
import ErrorPage from "../views/app/ErrorPage";
import Student from "../views/app/Student.vue";
import Teacher from "../views/app/Teacher.vue";
import MyNotes  from "../views/app/MyNotes.vue";
import Project from "../views/app/Project.vue";
import ModuleAffectation from "../views/app/ModuleAffectation.vue";
import NoteListModule from "../views/app/notes/List.vue";
import NoteEditModule from "../views/app/notes/NoteEditModule.vue";

global.API_URL="http://127.0.0.1:8000";

Vue.use(VueRouter);

global.ROLE_ADMIN = 1;
global.ROLE_TEACHER = 2;
global.ROLE_STUDENT = 3;

// Methodes communes
global.getLocalUser = () => {
  if (!localStorage.user) {
    return null;
  }

  return JSON.parse(localStorage.user);
}

global.isAdmin = () => {
  const user = getLocalUser();
  
  return user && user.role_id === ROLE_ADMIN;
}

global.isStudent = () => {
  const user = getLocalUser();

  return user && getLocalUser().role_id === ROLE_STUDENT;
}

global.isTeacher = () => {
  const user = getLocalUser();

  return user && getLocalUser().role_id === ROLE_TEACHER;
}

let homeComponent;

if (global.isAdmin()) {
  homeComponent = Student;
}

if (global.isTeacher()) {
  homeComponent = ModuleAffectation;
}

if (global.isStudent()) {
  homeComponent = MyNotes;
}


const routes = [
  {
    path: "/",
    name: "home",
    redirect: '/app' 
  },
  {
    path: "/404",
    name: "404",
    component: ErrorPage,
  },
  {
    path: "/app",
    name: "app",
    component: homeComponent,
  },
  {
    path: "/app/students",
    name: "students",
    component: Student,
    beforeEnter: (to, from, next) => {
      if (!global.isAdmin()) {
        next({ name: 'app'});
      }

      next();
    }
  },
  {
    path: "/app/teachers",
    name: "teachers",
    component: Teacher,
    beforeEnter: (to, from, next) => {
      if (!global.isAdmin()) {
        next({ name: 'app'});
      }

      next();
    }
  },
  {
    path: "/app/modules/affectation",
    name: "module-affectation",
    component: ModuleAffectation,
    beforeEnter: (to, from, next) => {
      if (!isTeacher()) {
        next({ name: 'app'});
      }

      next();
    }
  },
  {
    path: "/app/notes/affectation",
    name: "node-module-affectation",
    component: NoteListModule,
    beforeEnter: (to, from, next) => {
      if (!isTeacher()) {
        next({ name: 'app'});
      }

      next();
    }
  },
  {
    path: "/app/project/affectation",
    name: "node-project-affectation",
    component: Project,
    beforeEnter: (to, from, next) => {
      if (!isAdmin()) {
        next({ name: 'app'});
      }

      next();
    }
  },
  {
    path: "/app/notes/affectation/:id",
    name: "affect-note",
    component: NoteEditModule,
    beforeEnter: (to, from, next) => {
      if (!isTeacher()) {
        next({ name: 'app'});
      }

      next();
    }
  },
  {
    path: "/app/my-notes",
    name: "my-notes",
    component: MyNotes,
    beforeEnter: (to, from, next) => {
      if (!isStudent()) {
        next({ name: 'app'});
      }

      next();
    }
  },
  {
    path: "/login",
    name: "login",
    component: Login,
  },
  {
    path: '*',
    component: ErrorPage
  }
];

const router = new VueRouter({
  mode: "history",
  base: process.env.BASE_URL,
  routes,
});

export default router;
