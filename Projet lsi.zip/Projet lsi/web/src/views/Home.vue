<template>
  <div class="acceuil">
    <header>
      <HeadCar/>
      <NavBar/>
    </header>
    <section>
      <Presentation/>
    </section>
    <Foot/>
  </div>
</template>

<script>
// @ is an alias to /src
import HeadCar from "@/components/common/home/HeadCar.vue";
import NavBar from "@/components/common/home/NavBar.vue";
import Presentation from "@/components/common/home/Presentation.vue";
import Foot from "@/components/common/Foot.vue";

export default {
  name: "Home",
  components: {
    HeadCar,
    NavBar,
    Presentation,
    Foot,
  },
};
</script>