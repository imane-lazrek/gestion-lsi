<template>
  <div class="Authentification">
    <Authentification/>
  </div>
</template>

<script>
// @ is an alias to /src
import Authentification from "@/components/common/auth/Authentification.vue";

export default {
  name: "Login",
  components: {
    Authentification,
  },
};
</script>