<template>
  <App pageTitle="Liste des PFEs">
    <component :is="Content"></component>
  </App>
</template>

<script>
import App from "@/components/layout/App";
import Content from "@/components/app/projects/Project";

export default {
  name: "Projects",
  components: {
    App
  },
  data() {
    return {
      Content,
    };
  }
};
</script>