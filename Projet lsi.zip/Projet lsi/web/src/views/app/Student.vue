<template>
  <App pageTitle="Liste des etudiants">
    <component :is="Content"></component>
  </App>
</template>

<script>
import App from "@/components/layout/App";
import Content from "@/components/app/Student";


export default {
  name: "StudentsView",
  components: {
    App
  },
  data() {
    return {
      Content,
    };
  }
};
</script>