<template>
  <App pageTitle="Mes notes">
    <component :is="Content"></component>
  </App>
</template>

<script>
import App from "@/components/layout/App";
import Content from "@/components/app/MyNotes";

export default {
  name: "MyNotes",
  components: {
    App
  },
  data() {
    return {
      Content,
    };
  }
};
</script>