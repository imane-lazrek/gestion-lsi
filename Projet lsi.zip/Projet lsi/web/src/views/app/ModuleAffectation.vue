<template>
  <App pageTitle="Affection des modules">
    <component :is="Content"></component>
  </App>
</template>

<script>
import App from "@/components/layout/App";
import Content from "@/components/app/module/Affectation";

export default {
  name: "ModuleAffectation",
  components: {
    App
  },
  data() {
    return {
      Content,
    };
  }
};
</script>