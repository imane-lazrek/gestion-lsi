<template>
  <App pageTitle="Page introuvable">
    <component :is="Content"></component>
  </App>
</template>

<script>
import App from "@/components/layout/App";
import Content from "@/components/ErrorPage";

export default {
  name: "Dashboard",
  components: {
    App
  },
  data() {
    return {
      Content
    };
  },
  mounted() {
    if (!localStorage.user) {
      this.$router.push('login');
    }
  }
};
</script>