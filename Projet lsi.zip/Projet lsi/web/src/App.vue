<template>
  <div id="app">
    <div id="nav">
      <router-view />
    </div>
  </div>
</template>

<script>
export default {
  components: {},
  computed: {
    loaded() {
      return this.$store.state.loadState == "loaded";
    }
  }
};
</script> 

<style lang="scss">
  @import "./assets/template/css/adminlte.min.css";
  @import "./assets/template/plugins/fontawesome-free/css/all.min.css";
  @import "./../node_modules/toastr/toastr.scss";
</style>
