<template>
    <div class="error-page">
            <h2 class="headline text-warning"> 404</h2>

            <div class="error-content">
            <h3><i class="fas fa-exclamation-triangle text-warning"></i> Oops! Page introuvable</h3>

            <p>
                On a pas trouvé votre page
                <router-link>Veuillez clicker ici pour retourner à l'application</router-link>
            </p>
            <!-- /.error-content -->
        </div>
        </div>
</template>

<script>
export default {
  name: "ErrorPage",
  props: {
   
  },
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
body {
    background: #dedede;
}
.page-wrap {
    min-height: 100vh;
}
</style>