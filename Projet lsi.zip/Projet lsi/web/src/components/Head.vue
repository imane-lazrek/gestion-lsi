<template>
  <div class="Head">
    
  </div>
</template>

<script>
export default {
  name: "Head",
  props: {
    
  },
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>