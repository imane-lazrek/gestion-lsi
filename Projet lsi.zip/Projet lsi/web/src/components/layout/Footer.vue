<template>
    <footer class="main-footer">
        <strong>Copyright &copy; 2021 <a href="#">Lsi Fst</a>.</strong> Tous les droits sont reservés
    </footer>
</template>