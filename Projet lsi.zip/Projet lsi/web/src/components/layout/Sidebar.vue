<template>
    <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="#" class="brand-link">
      <!-- <img src="#" alt="Logo" class="brand-image img-circle elevation-3" style="opacity: .8"> -->
      <span class="brand-text font-weight-light">Gestion Lsi</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="info">
            <router-link class="d-block" to="/app">{{user.first_name}} {{user.last_name}}</router-link>
        </div>
      </div>

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <li class="nav-item">
            <router-link class="nav-link" to="/app/teachers" v-if="isAdmin()">
                <i class="nav-icon fas fa-th"></i>
                <p>
                    Gestion des profs
                </p>
            </router-link>
            <router-link class="nav-link" to="/app/students" v-if="isAdmin()">
                <i class="nav-icon fas fa-user"></i>
                <p>
                    Gestion des étudiants
                </p>
            </router-link>
            <router-link class="nav-link" to="/app/modules/affectation" v-if="isTeacher()">
                <i class="nav-icon fas fa-user"></i>
                <p>
                    Gestion des modules
                </p>
            </router-link>
            <router-link class="nav-link" to="/app/notes/affectation" v-if="isTeacher()">
                <i class="nav-icon fas fa-user"></i>
                <p>
                    Gestion des notes
                </p>
            </router-link>
            <router-link class="nav-link" to="/app/project/affectation" v-if="isAdmin()">
                <i class="nav-icon fas fa-user"></i>
                <p>
                    Gestion des PFE
                </p>
            </router-link>
             <router-link class="nav-link" to="/app/my-notes" v-if="isStudent()">
                <i class="nav-icon fas fa-user"></i>
                <p>
                    Mes notes
                </p>
            </router-link>

            <a style="margin-top: 20px" href="#" v-on:click="logout()" class="nav-link">
              <i class="nav-icon fas fa-sign-out-alt"></i>
              <p>
                Se deconnecter
              </p>
            </a>
          </li>
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>
</template>

<script>
export default {
    name: "Sidebar",
    data() {
        return {
            user: {}
        }
    },
    mounted() {
        this.user = global.getLocalUser();
    },
    methods: {
        logout: () => {
            global.logout();
        }
    }
};
</script>
