<template>
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>{{pageTitle}}</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item">
                  <router-link to="dashboard">Tableau de bord</router-link>
                </li>
              <!-- <li class="breadcrumb-item active" v-if="pageTitle">{{pageTitle}}</li> -->
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
</template>

<script>
export default {
    name: 'Breadcrumb',
    props: ['pageTitle']
};
</script>
