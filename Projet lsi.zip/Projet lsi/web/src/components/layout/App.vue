<template>
  <div class="wrapper">
  <Header/>
  <Sidebar/>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- <Breadcrumb :pageTitle="pageTitle"/> -->
    <!-- Main content -->
    <section class="content mt-5">
      <!-- Default box -->
      <div class="card">
        <div class="card-header">
          <h3 class="card-title">{{ pageTitle }}</h3>
        </div>
        <div class="card-body">
          <slot></slot>
        </div>
        <!-- /.card-body -->
        <div class="card-footer">
        </div>
        <!-- /.card-footer-->
      </div>
      <!-- /.card -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <Footer/>
</div>
</template>

<style>
  .btn.btn-xs {
    padding: .25rem .4rem;
    font-size: .875rem;
    line-height: .5;
    border-radius: .2rem;
  }

  .ml-2 {
    margin-left: 10px;
  }
  .mr-2 {
    margin-right: 10px;
  }
</style>

<script>
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import Sidebar from "@/components/layout/Sidebar";
import Breadcrumb from "@/components/layout/Breadcrumb";

export default {
  name: "App",
  components: {
    Header,
    Footer,
    Sidebar,
    Breadcrumb
  },
  props: ['pageTitle', 'component'],
  mounted() {
    if (!localStorage.user) {
      this.$router.push('login');
    }
  }
};
</script>