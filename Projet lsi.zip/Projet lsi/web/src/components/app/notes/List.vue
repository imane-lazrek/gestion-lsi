<template>
  <div>
    <table class="table table-striped">
      <thead>
        <th>Nom</th>
        <th>Prénom</th>
        <th>Modules</th>
        <th>Action</th>
      </thead>
      <tbody>
        <tr v-for="user in users" :key="user.id">
          <td>{{ user.last_name }}</td>
          <td>{{ user.first_name }}</td>
          <td>
            <div v-for="module in user.modules" :key="module.id">
              - {{ module.name}}
            </div>
          </td>
          <td>
              <router-link v-if="user.modules.length" :to="{name: 'affect-note', params: {id: user.id}}">Enregistrer les notes</router-link>
              <span href="#" v-if="!user.modules.length">- (Modules manquants)</span>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
export default {
  name: "NoteAffectation",
  data() {
    return {
      users: [],
      modules: [],
    };
  },
  methods: {
    async getUsers() {
      this.users = await service.users.list(global.ROLE_STUDENT);
    },
    async getModules() {
      this.modules = await service.modules.list();
    },
  },
  mounted() {
    this.getUsers();
  }
};
</script>