<template>
  <div>
    <table class="table table-striped">
      <thead>
        <th>Module</th>
        <th>Note</th>
        <th></th>
      </thead>
      <tbody>
        <tr v-for="module in currentUser.modules" :key="module.id">
          <td>{{ module.name }}</td>
          <td>
            <span v-if="!module.pivot.note">-</span>
            <span v-if="module.pivot.note">{{ module.pivot.note }}</span>
          </td>
          <td>
              <button class="btn btn-success btn-sm mr-2" v-on:click="openModal({
                id: module.id,
                note: module.pivot.note,
                name: module.name
                })">Modifier</button>
          </td>
        </tr>
      </tbody>
    </table>

    <div id="app-modal" class="modal" tabindex="-1" role="dialog">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <form v-on:submit.prevent="handleForm" method="post">
            <div class="modal-header">
              <h5 class="modal-title">
                <span>Modifier une note</span>
              </h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">

                <div class="form-group">
                  <div><b>Etudiant</b>: {{currentUser.first_name }} {{ currentUser.last_name }}</div>
                  <div><b>Module</b> {{module.name}}</div>
                </div>

                <div class="form-group">
                    <label>Note</label>
                    <input class="form-control" type="number" max="20" name="note" v-model="module.note"  required/>
                </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-primary" v-on:click="handleForm">Enregistrer</button>
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import toastr from 'toastr';
export default {
  name: "NoteAffectation",
  data() {
    return {
      userId: null,
      module: {},
      moduleIds: [],
      currentUser: {},
    };
  },
  methods: {
    async getCurrentUser() {
      this.currentUser = await global.service.users.get(this.userId);
    },
    async openModal(module) {
      this.module = module;

      
      global.$('#app-modal').modal('show');      
    },
    async handleForm () {
      if (this.module.note > 20) {
        toastr.error("La note maximal est 20/20");
        return false;
      }

      const response = await global.service.modules.note(this.currentUser.id, this.module);

      if (response) {
        this.currentUser = {};
        
        global.$('#app-modal').modal('hide');
        
        this.module = {};

        this.getCurrentUser();

      }
    }
  },
  mounted() {
    this.userId = this.$route.params.id;

    this.getCurrentUser();
  }
};
</script>