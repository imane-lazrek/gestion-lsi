<template>
  <div>
      <table class="table table-striped">
      <thead>
        <th>PFE</th>
        <th>Note</th>
      </thead>
      <tbody>
        <tr>
            <td>{{ currentUser.project.name }}</td>
            <td>{{ currentUser.project.note }}</td>
        </tr>
      </tbody>
    </table>

    <table class="table table-striped">
      <thead>
        <th>Module</th>
        <th>Note</th>
      </thead>
      <tbody>
        <tr v-for="module in currentUser.modules" :key="module.id">
          <td>{{ module.name }}</td>
          <td>
            <span v-if="!module.pivot.note">-</span>
            <span v-if="module.pivot.note">{{ module.pivot.note }}</span>
          </td>
        </tr>
        <tr v-if="!currentUser.modules || currentUser.modules.length === 0">
            <td colspan="10">Aucun resultat disponible</td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
export default {
  name: "Notes",
  data() {
    return {
      currentUser: {},
    };
  },
  methods: {
    async getUsers() {
        const user = global.getLocalUser();
        if (!user) {
            global.logout();

            return false;
        }
        
        this.currentUser = await service.users.get(user.id);
    },
  },
  mounted() {
    this.getUsers();
  }
};
</script>