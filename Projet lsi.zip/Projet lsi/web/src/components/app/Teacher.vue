<template>
  <div>
    <div>
        <button style="margin-bottom: 10px" class="btn btn-primary btn-sm float-right" v-on:click="openModal()">Ajouter</button>
    </div>
    <table class="table table-stripeed">
      <thead>
        <th>Nom</th>
        <th>Prenom</th>
        <th>Email</th>
        <th>Action</th>
      </thead>
      <tbody>
        <tr v-for="user in users" :key="user.id">
          <td>{{ user.last_name }}</td>
          <td>{{ user.first_name }}</td>
          <td>{{ user.email }}</td>
          <td>
              <button class="btn btn-success btn-sm mr-2" v-on:click="openModal(user.id)">Modifier</button>
              <button class="btn btn-danger btn-sm" v-on:click="deleteUser(user.id)">Supprimer</button>
          </td>
        </tr>
      </tbody>
    </table>

    <div id="app-modal" class="modal" tabindex="-1" role="dialog">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <form v-on:submit.prevent="saveUser" method="post">
            <div class="modal-header">
              <h5 class="modal-title">
                <span v-if="currentUser.id">Modifier un professeur</span>
                <span v-if="!currentUser.id">Ajouter un professeur</span>
              </h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label>Email</label>
                    <input class="form-control" type="email" v-model="currentUser.email" name="email" required>
                </div>
                <div class="form-group">
                    <label>Prenom</label>
                    <input class="form-control" type="text" v-model="currentUser.first_name" name="first_name" required>
                </div>
                <div class="form-group">
                    <label>Nom</label>
                    <input class="form-control" type="text" v-model="currentUser.last_name" name="last_name" required>
                </div>
                <div class="form-group">
                    <label>Mot de passe</label>
                    <input class="form-control" type="password" name="password" v-model="currentUser.password" v-if="currentUser.id">
                    <input class="form-control" type="password" name="password" v-model="currentUser.password" v-if="!currentUser.id" required>
                </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-primary" v-on:click="saveUser">Enregistrer</button>
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Teachers",
  data() {
    return {
      users: [],
      currentUser: {},
    };
  },
  methods: {
    async getUsers() {
      this.users = await service.users.list(global.ROLE_TEACHER);
    },
    async deleteUser(userId) {
      await service.users.delete(userId);

      this.getUsers();
    },
    async openModal(userId = false) {
      this.currentUser = {};
      if (userId) {
        this.currentUser = await service.users.get(userId);
      }

      $('#app-modal').modal('show');      
    },
    async saveUser () {
      this.currentUser.role_id = global.ROLE_TEACHER;
      
      let response;

      if (this.currentUser.id) {
        response = await service.users.edit(this.currentUser.id, this.currentUser);
      } else {
        response = await service.users.create(this.currentUser);
      }

      if (response) {
        this.currentUser = {};
        
        $('#app-modal').modal('hide');
        this.users = await service.users.list(global.ROLE_TEACHER);
      }
    }
  },
  mounted() {
    this.getUsers();
  }
};
</script>