<template>
  <div>
    <div>
        <button style="margin-bottom: 10px" class="btn btn-primary btn-sm float-right" v-on:click="openModal()">Ajouter</button>
    </div>
    <table class="table table-striped">
      <thead>
        <th>PFE</th>
        <th>Students</th>
        <th>Note</th>
        <th>Action</th>
      </thead>
      <tbody>
        <tr v-for="project in projects" :key="project.id">
          <td>{{ project.name }}</td>
          <td>
            <div v-for="user in project.users" :key="user.id">
              {{ user.first_name }} {{ user.last_name }}
            </div>
          </td>
          <td>{{ project.note }}</td>
          <td>
              <button class="btn btn-success btn-sm mr-2" v-on:click="openModal(project.id)">Modifier</button>
              <button class="btn btn-danger btn-sm" v-on:click="deleteProject(project.id)">Supprimer</button>
          </td>
        </tr>
      </tbody>
    </table>

    <div id="app-modal" class="modal" tabindex="-1" role="dialog">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <form v-on:submit.prevent="handleForm" method="post">
            <div class="modal-header">
              <h5 class="modal-title">
                <span v-if="currentProject.id">Modifier un Pfe</span>
                <span v-if="!currentProject.id">Ajouter un Pfe</span>
              </h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label>Projet</label>
                    <input class="form-control" type="text" v-model="currentProject.name" name="project" required>
                </div>
                <div class="form-group">
                    <label>Student</label>
                    {{userIds}}
                    <select class="form-control"
                            multiple
                            name="users[]"
                            v-model="userIds"
                            id="users">
                        <option v-for="user in users" :key="user.id" :value="user.id">
                          {{user.id}} - {{ user.first_name }} - {{ user.last_name }}
                        </option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Note</label>
                    <input class="form-control" type="number" v-model="currentProject.note" name="note">
                </div>
            </div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-primary">Enregistrer</button>
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Teachers",
  data() {
    return {
      users: [],
      userIds: [],
      projects: [],
      currentProject: {},
    };
  },
  methods: {
    async getProjects() {
      this.projects = await service.projects.list();
    },
    async getUsers() {
      this.users = await service.users.list(global.ROLE_STUDENT);
    },
    async deleteProject(id) {
      await service.projects.delete(id);

      this.getProjects();
    },
    async openModal(projectId = false) {
      this.currentProject = {};

      if (projectId) {
        this.currentProject = await service.projects.get(projectId);
      }

      this.userIds = [];
      if (this.currentProject.users) {
        this.currentProject.users.map((v) => {
          this.userIds.push(v.id);
        });
      }

      $('#app-modal').modal('show');      
    },
    async handleForm () {
      let response;

      if (this.currentProject.id) {
        response = await service.projects.edit(this.currentProject.id, this.currentProject, this.userIds);
      } else {
        response = await service.projects.create(this.currentProject, this.userIds);
      }

      if (response) {
        this.currentProject = {};
        
        $('#app-modal').modal('hide');
        this.projects = await service.projects.list();
      }
    }
  },
  mounted() {    
    this.getUsers();
    this.getProjects();
  }
};
</script>