<template>
  <div>
    <table class="table table-striped">
      <thead>
        <th>Nom</th>
        <th>Prénom</th>
        <th>Modules</th>
        <th>Action</th>
      </thead>
      <tbody>
        <tr v-for="user in users" :key="user.id">
          <td>{{ user.last_name }}</td>
          <td>{{ user.first_name }}</td>
          <td>
            <div v-for="module in user.modules" :key="module.id">
              - {{ module.name}}
            </div>
          </td>
          <td>
              <button class="btn btn-success btn-sm mr-2" v-on:click="openModal(user.id)">Modifier</button>
          </td>
        </tr>
      </tbody>
    </table>

    <div id="app-modal" class="modal" tabindex="-1" role="dialog">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <form v-on:submit.prevent="handleForm" method="post">
            <div class="modal-header">
              <h5 class="modal-title">
                <span>Affecter les modules pour {{currentUser.first_name }} {{ currentUser.last_name }}</span>
              </h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label>Modules</label>
                    <select class="form-control"
                            multiple
                            name="modules[]"
                            v-model="moduleIds"
                            id="modules">
                        <option v-for="module in modules" :key="module.id" :value="module.id">
                          {{ module.name }}
                        </option>
                    </select>
                </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-primary" v-on:click="handleForm">Enregistrer</button>
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Affectation",
  data() {
    return {
      users: [],
      modules: [],
      moduleIds: [],
      currentUser: {},
    };
  },
  methods: {
    getModulesAsString (modules) {
      if (!(modules)) {
        return;
      }

      let modulesNames = []
      modules.map((v) => {
        modulesNames.push(v.name);
      });

      return modulesNames.join(', ');
    },
    async getUsers() {
      this.users = await service.users.list(global.ROLE_STUDENT);
    },
    async getModules() {
      this.modules = await service.modules.list();
    },
    async openModal(userId) {
      this.currentUser = await service.users.get(userId);
      this.getModules();

      if (this.currentUser.modules) {
        this.currentUser.modules.map((v) => {
          this.moduleIds.push(v.id);
        });
      }
      
      $('#app-modal').modal('show');      
    },
    async handleForm () {
      const response = await service.modules.affect(this.currentUser.id, this.moduleIds);

      if (response) {
        this.currentUser = {};
        
        $('#app-modal').modal('hide');
        this.users = await service.users.list(global.ROLE_STUDENT);
      }
    }
  },
  mounted() {
    this.getUsers();
  }
};
</script>