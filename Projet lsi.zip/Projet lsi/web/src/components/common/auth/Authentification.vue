	<template>
	<div class="container">
		<div class="card mt-5">
		<div class="card-body login-card-body">
		<p class="login-box-msg">Se connecter</p>

		<form v-on:submit.prevent="handleForm" method="post">
			<div class="input-group mb-3">
			<input type="email" v-model="email" class="form-control" placeholder="Email">
			<div class="input-group-append">
				<div class="input-group-text">
				<span class="fas fa-envelope"></span>
				</div>
			</div>
			</div>
			<div class="input-group mb-3">
			<input type="password" v-model="password" class="form-control" placeholder="Mot de passe">
			<div class="input-group-append">
				<div class="input-group-text">
				<span class="fas fa-lock"></span>
				</div>
			</div>
			</div>
			<div class="row">
			<div class="col-4">
				<button type="submit" class="btn btn-primary btn-block">Se connecter</button>
			</div>

			</div>
		</form>
		</div>
		<!-- /.social-auth-links -->
	</div>
	</div>
	<!-- /.login-card-body -->
	</template>

	<script>
	import axios from "axios";
	import toastr from "toastr";

	export default {
		name: "Authentification",
		props: {
		},
		data() {
			return {
				email: '',
				password: ''
			}
		},
		methods: {
			handleForm() {
				axios.post(API_URL + '/api/auth/login', {
					email: this.email, 
					password: this.password, 
				}).then((response) => {
					toastr.success("Connection avec succès");

					localStorage.setItem('user', JSON.stringify(response.data.user));
					localStorage.setItem('token', response.data['access-token']);

					window.location = '/app';
				}).catch(err => {
					toastr.error("Erreur lors de la connexion");
					console.log(err);
				});
			}
		},
		mounted() {
		}
	};
	</script>

	<!-- Add "scoped" attribute to limit CSS to this component only -->
	<style scoped lang="scss">
	</style>